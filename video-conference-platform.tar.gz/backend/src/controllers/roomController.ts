import { Request, Response } from 'express';
import { z } from 'zod';
import { roomService } from '../services/roomService.js';

const createRoomSchema = z.object({
  name: z.string().min(1).max(100).optional(),
  isPrivate: z.boolean().optional(),
  maxParticipants: z.number().min(2).max(50).optional(),
});

const joinRoomSchema = z.object({
  name: z.string().min(1).max(50),
});

export const roomController = {
  // POST /api/rooms - Create a new room
  async createRoom(req: Request, res: Response) {
    try {
      const data = createRoomSchema.parse(req.body);
      
      const room = roomService.createRoom({
        name: data.name,
        isPrivate: data.isPrivate,
        maxParticipants: data.maxParticipants,
      });

      res.status(201).json({
        success: true,
        data: {
          id: room.id,
          name: room.name,
          url: `/room/${room.id}`,
          hostToken: room.hostToken,
          isPrivate: room.isPrivate,
          maxParticipants: room.maxParticipants,
          createdAt: room.createdAt,
        },
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({
          success: false,
          error: {
            message: 'Invalid request data',
            details: error.errors,
          },
        });
        return;
      }
      console.error('Error creating room:', error);
      res.status(500).json({
        success: false,
        error: {
          message: 'Failed to create room',
        },
      });
    }
  },

  // GET /api/rooms/:id - Get room info
  async getRoom(req: Request, res: Response) {
    try {
      const { id } = req.params;
      const room = roomService.getRoom(id);

      if (!room) {
        res.status(404).json({
          success: false,
          error: {
            message: 'Room not found',
          },
        });
        return;
      }

      res.json({
        success: true,
        data: {
          id: room.id,
          name: room.name,
          isPrivate: room.isPrivate,
          isLocked: room.isLocked,
          participantCount: room.participants.size,
          maxParticipants: room.maxParticipants,
        },
      });
    } catch (error) {
      console.error('Error getting room:', error);
      res.status(500).json({
        success: false,
        error: {
          message: 'Failed to get room',
        },
      });
    }
  },

  // GET /api/rooms - List all rooms (for debugging)
  async listRooms(req: Request, res: Response) {
    try {
      const rooms = roomService.getAllRooms();
      const stats = roomService.getStats();

      res.json({
        success: true,
        data: {
          rooms: rooms.map(room => ({
            id: room.id,
            name: room.name,
            participantCount: room.participants.size,
            maxParticipants: room.maxParticipants,
            createdAt: room.createdAt,
          })),
          stats,
        },
      });
    } catch (error) {
      console.error('Error listing rooms:', error);
      res.status(500).json({
        success: false,
        error: {
          message: 'Failed to list rooms',
        },
      });
    }
  },

  // POST /api/rooms/:id/join - Validate join request
  async validateJoin(req: Request, res: Response) {
    try {
      const { id } = req.params;
      const data = joinRoomSchema.parse(req.body);
      
      const room = roomService.getRoom(id);

      if (!room) {
        res.status(404).json({
          success: false,
          error: {
            message: 'Room not found',
          },
        });
        return;
      }

      if (room.isLocked && !req.headers['x-host-token']) {
        res.status(403).json({
          success: false,
          error: {
            message: 'Room is locked',
          },
        });
        return;
      }

      if (room.participants.size >= room.maxParticipants) {
        res.status(403).json({
          success: false,
          error: {
            message: 'Room is full',
          },
        });
        return;
      }

      res.json({
        success: true,
        data: {
          canJoin: true,
          roomName: room.name,
          participantCount: room.participants.size,
        },
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({
          success: false,
          error: {
            message: 'Invalid request data',
            details: error.errors,
          },
        });
        return;
      }
      console.error('Error validating join:', error);
      res.status(500).json({
        success: false,
        error: {
          message: 'Failed to validate join',
        },
      });
    }
  },
};