import { Routes, Route } from 'react-router-dom';
import HomePage from './pages/home/HomePage';
import CreateRoomPage from './pages/create/CreateRoomPage';
import RoomPage from './pages/room/RoomPage';

function App() {
  return (
    <div className='min-h-screen bg-dark-300'>
      <Routes>
        <Route path='/' element={<HomePage />} />
        <Route path='/create' element={<CreateRoomPage />} />
        <Route path='/room/:roomId' element={<RoomPage />} />
      </Routes>
    </div>
  );
}

export default App;