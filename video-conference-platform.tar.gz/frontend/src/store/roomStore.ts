import { create } from 'zustand';
import type { Participant, Room, ChatMessage, MediaState } from '@/types';

interface RoomState {
  // Room info
  room: Room | null;
  roomId: string | null;
  isHost: boolean;
  participantId: string | null;
  
  // Participants
  participants: Map<string, Participant>;
  localStream: MediaStream | null;
  
  // Media state
  mediaState: MediaState;
  
  // Chat
  messages: ChatMessage[];
  
  // UI State
  isConnected: boolean;
  isConnecting: boolean;
  error: string | null;
  
  // Actions
  setRoom: (room: Room | null) => void;
  setRoomId: (roomId: string | null) => void;
  setIsHost: (isHost: boolean) => void;
  setParticipantId: (id: string | null) => void;
  
  setLocalStream: (stream: MediaStream | null) => void;
  updateParticipant: (participant: Participant) => void;
  addParticipant: (participant: Participant) => void;
  removeParticipant: (participantId: string) => void;
  setParticipants: (participants: Participant[]) => void;
  
  toggleAudio: () => void;
  toggleVideo: () => void;
  toggleScreenShare: () => void;
  
  addMessage: (message: ChatMessage) => void;
  
  setConnected: (connected: boolean) => void;
  setConnecting: (connecting: boolean) => void;
  setError: (error: string | null) => void;
  
  reset: () => void;
}

const initialMediaState: MediaState = {
  hasAudio: true,
  hasVideo: true,
  screenShare: false,
};

export const useRoomStore = create<RoomState>((set, get) => ({
  // Initial state
  room: null,
  roomId: null,
  isHost: false,
  participantId: null,
  participants: new Map(),
  localStream: null,
  mediaState: initialMediaState,
  messages: [],
  isConnected: false,
  isConnecting: false,
  error: null,

  // Actions
  setRoom: (room) => set({ room }),
  setRoomId: (roomId) => set({ roomId }),
  setIsHost: (isHost) => set({ isHost }),
  setParticipantId: (id) => set({ participantId: id }),

  setLocalStream: (stream) => set({ localStream: stream }),

  updateParticipant: (participant) => {
    const participants = new Map(get().participants);
    participants.set(participant.id, participant);
    set({ participants });
  },

  addParticipant: (participant) => {
    const participants = new Map(get().participants);
    participants.set(participant.id, participant);
    set({ participants });
  },

  removeParticipant: (participantId) => {
    const participants = new Map(get().participants);
    participants.delete(participantId);
    set({ participants });
  },

  setParticipants: (participantsList) => {
    const participants = new Map<string, Participant>();
    participantsList.forEach((p) => participants.set(p.id, p));
    set({ participants });
  },

  toggleAudio: () => {
    const { localStream, mediaState } = get();
    if (localStream) {
      localStream.getAudioTracks().forEach((track) => {
        track.enabled = !mediaState.hasAudio;
      });
    }
    set({ mediaState: { ...mediaState, hasAudio: !mediaState.hasAudio } });
  },

  toggleVideo: () => {
    const { localStream, mediaState } = get();
    if (localStream) {
      localStream.getVideoTracks().forEach((track) => {
        track.enabled = !mediaState.hasVideo;
      });
    }
    set({ mediaState: { ...mediaState, hasVideo: !mediaState.hasVideo } });
  },

  toggleScreenShare: () => {
    set((state) => ({ mediaState: { ...state.mediaState, screenShare: !state.mediaState.screenShare } }));
  },

  addMessage: (message) => set((state) => ({ messages: [...state.messages, message] })),

  setConnected: (connected) => set({ isConnected: connected }),
  setConnecting: (connecting) => set({ isConnecting: connecting }),
  setError: (error) => set({ error }),

  reset: () =>
    set({
      room: null,
      roomId: null,
      isHost: false,
      participantId: null,
      participants: new Map(),
      localStream: null,
      mediaState: initialMediaState,
      messages: [],
      isConnected: false,
      isConnecting: false,
      error: null,
    }),
}));