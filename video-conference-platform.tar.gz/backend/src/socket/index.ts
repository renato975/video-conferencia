import { Server } from 'socket.io';
import { config } from '../config/env.js';
import { setupSignaling } from './signalingHandler.js';

let io: Server | null = null;

export function initializeSocket(server: any) {
  io = new Server(server, {
    cors: {
      origin: config.cors.origin,
      credentials: true,
    },
    transports: ['websocket', 'polling'],
    pingTimeout: 60000,
    pingInterval: 25000,
  });

  setupSignaling(io);

  console.log('[Socket.io] Server initialized');

  return io;
}

export function getIO(): Server | null {
  return io;
}