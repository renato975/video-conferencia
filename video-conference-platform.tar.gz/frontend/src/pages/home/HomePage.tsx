import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Video, ArrowRight } from 'lucide-react';
import apiService from '@/services/api';

export default function HomePage() {
  const navigate = useNavigate();
  const [roomId, setRoomId] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleJoinRoom = async () => {
    if (!roomId.trim()) {
      setError('Please enter a room ID');
      return;
    }

    setIsLoading(true);
    setError(null);

    try {
      // Validate room exists
      const response = await apiService.getRoom(roomId.trim());
      
      if (response.success) {
        navigate(`/room/${roomId.trim()}`);
      } else {
        setError('Room not found');
      }
    } catch (err) {
      setError('Failed to join room. Please check the room ID.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleCreateRoom = () => {
    navigate('/create');
  };

  return (
    <div className='min-h-screen flex flex-col items-center justify-center p-4'>
      {/* Background Pattern */}
      <div className='absolute inset-0 overflow-hidden pointer-events-none'>
        <div className='absolute top-1/4 left-1/4 w-96 h-96 bg-primary-500/10 rounded-full blur-3xl' />
        <div className='absolute bottom-1/4 right-1/4 w-96 h-96 bg-primary-500/10 rounded-full blur-3xl' />
      </div>

      <div className='relative z-10 w-full max-w-md space-y-8'>
        {/* Logo & Title */}
        <div className='text-center space-y-4'>
          <div className='inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-primary-600 mb-4'>
            <Video className='w-8 h-8 text-white' />
          </div>
          <h1 className='text-4xl font-bold text-white'>Video Conference</h1>
          <p className='text-gray-400'>Simple, instant video meetings</p>
        </div>

        {/* Join Room Card */}
        <div className='bg-dark-200 rounded-2xl border border-dark-100 p-6 space-y-4'>
          <div>
            <label className='block text-sm text-gray-400 mb-2'>Enter room ID</label>
            <input
              type='text'
              value={roomId}
              onChange={(e) => setRoomId(e.target.value)}
              placeholder='abc-def-ghi'
              className='
                w-full px-4 py-3 rounded-xl
                bg-dark-100 text-white text-center text-lg
                border border-dark-300
                focus:outline-none focus:border-primary-500
                placeholder-gray-600
              '
              onKeyDown={(e) => e.key === 'Enter' && handleJoinRoom()}
            />
          </div>

          {error && (
            <p className='text-red-400 text-sm text-center'>{error}</p>
          )}

          <button
            onClick={handleJoinRoom}
            disabled={isLoading}
            className='
              w-full py-3 px-4 rounded-xl
              bg-primary-600 hover:bg-primary-700
              disabled:bg-dark-300 disabled:cursor-not-allowed
              text-white font-medium
              flex items-center justify-center gap-2
              transition-colors
            '
          >
            {isLoading ? (
              <div className='w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin' />
            ) : (
              <>
                Join Room
                <ArrowRight className='w-5 h-5' />
              </>
            )}
          </button>
        </div>

        {/* Divider */}
        <div className='flex items-center gap-4'>
          <div className='flex-1 h-px bg-dark-100' />
          <span className='text-gray-500 text-sm'>or</span>
          <div className='flex-1 h-px bg-dark-100' />
        </div>

        {/* Create Room Card */}
        <button
          onClick={handleCreateRoom}
          className='
            w-full p-6 rounded-2xl
            bg-dark-200 hover:bg-dark-100
            border border-dark-100
            text-left
            transition-colors
          '
        >
          <div className='flex items-center justify-between'>
            <div>
              <h2 className='text-lg font-semibold text-white mb-1'>Create a Room</h2>
              <p className='text-gray-400 text-sm'>Generate a unique link to share</p>
            </div>
            <ArrowRight className='w-5 h-5 text-gray-400' />
          </div>
        </button>
      </div>

      {/* Footer */}
      <div className='absolute bottom-4 text-center'>
        <p className='text-gray-600 text-sm'>No account needed • Free forever</p>
      </div>
    </div>
  );
}