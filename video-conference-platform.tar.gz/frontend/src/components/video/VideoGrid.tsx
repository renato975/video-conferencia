import { VideoTile } from './VideoTile';
import { useRoomStore } from '@/store/roomStore';
import { useWebRTC } from '@/hooks/useWebRTC';

interface VideoGridProps {
  onPeerStream?: (peerId: string, stream: MediaStream) => void;
}

export function VideoGrid({ onPeerStream }: VideoGridProps) {
  const { participants, localStream, participantId, mediaState } = useRoomStore();

  // Get all participants as array
  const participantsArray = Array.from(participants.values());
  
  // Calculate grid layout
  const totalVideos = participantsArray.length + (localStream ? 1 : 0);
  
  const getGridClass = () => {
    if (totalVideos === 1) return 'grid-cols-1';
    if (totalVideos === 2) return 'grid-cols-2';
    if (totalVideos <= 4) return 'grid-cols-2';
    if (totalVideos <= 6) return 'grid-cols-3';
    if (totalVideos <= 9) return 'grid-cols-3';
    return 'grid-cols-4';
  };

  return (
    <div className={`
      grid ${getGridClass()} gap-4 p-4
      h-full w-full
      auto-rows-fr
    `}>
      {/* Local Video */}
      {localStream && (
        <VideoTile
          stream={localStream}
          name={participants.get(participantId || '')?.name || 'You'}
          isLocal
          isHost={participants.get(participantId || '')?.isHost}
          hasAudio={mediaState.hasAudio}
          hasVideo={mediaState.hasVideo}
        />
      )}

      {/* Remote Videos */}
      {participantsArray
        .filter((p) => p.id !== participantId)
        .map((participant) => (
          <VideoTile
            key={participant.id}
            name={participant.name}
            isHost={participant.isHost}
            hasAudio={participant.hasAudio}
            hasVideo={participant.hasVideo}
            // Stream would come from WebRTC peer connection
            stream={undefined}
          />
        ))}
    </div>
  );
}

export default VideoGrid;