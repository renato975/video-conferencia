import { Router } from 'express';
import { roomController } from '../controllers/roomController.js';

const router = Router();

// Create a new room
router.post('/rooms', roomController.createRoom);

// List all rooms (debug endpoint)
router.get('/rooms', roomController.listRooms);

// Get room info
router.get('/rooms/:id', roomController.getRoom);

// Validate join request
router.post('/rooms/:id/join', roomController.validateJoin);

export default router;