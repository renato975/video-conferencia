export interface Participant {
  id: string;
  socketId: string;
  name: string;
  isHost: boolean;
  hasAudio: boolean;
  hasVideo: boolean;
  joinedAt: Date;
}

export interface Room {
  id: string;
  name: string;
  hostToken: string;
  isPrivate: boolean;
  isLocked: boolean;
  maxParticipants: number;
  participants: Map<string, Participant>;
  createdAt: Date;
  updatedAt: Date;
}

export interface ChatMessage {
  id: string;
  roomId: string;
  senderId: string;
  senderName: string;
  text: string;
  timestamp: Date;
}

export interface CreateRoomDTO {
  name: string;
  isPrivate?: boolean;
  maxParticipants?: number;
}

export interface JoinRoomDTO {
  name: string;
}

export interface HostActionDTO {
  action: 'kick' | 'mute' | 'lock' | 'unlock' | 'end';
  targetId?: string;
}

export interface WebRTCSignal {
  type: 'offer' | 'answer' | 'ice-candidate';
  from: string;
  to: string;
  payload: any;
}

// Socket event types
export interface ServerToClientEvents {
  'room-joined': (data: { roomId: string; participants: Participant[]; isHost: boolean }) => void;
  'room-updated': (data: { room: Partial<Room> }) => void;
  'participant-joined': (participant: Participant) => void;
  'participant-left': (data: { participantId: string }) => void;
  'participant-updated': (participant: Participant) => void;
  'offer': (data: { from: string; offer: any }) => void;
  'answer': (data: { from: string; answer: any }) => void;
  'ice-candidate': (data: { from: string; candidate: any }) => void;
  'chat-message': (message: ChatMessage) => void;
  'room-locked': () => void;
  'room-unlocked': () => void;
  'kicked': () => void;
  'error': (error: { message: string; code?: string }) => void;
}

export interface ClientToServerEvents {
  'join-room': (data: { roomId: string; name: string }, callback: (response: any) => void) => void;
  'leave-room': (data: {}, callback: (response: any) => void) => void;
  'offer': (data: { to: string; offer: any }) => void;
  'answer': (data: { to: string; answer: any }) => void;
  'ice-candidate': (data: { to: string; candidate: any }) => void;
  'chat-message': (data: { text: string }) => void;
  'host-action': (data: HostActionDTO, callback: (response: any) => void) => void;
  'update-media-state': (data: { hasAudio: boolean; hasVideo: boolean }) => void;
}