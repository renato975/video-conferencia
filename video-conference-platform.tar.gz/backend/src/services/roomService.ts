import { v4 as uuidv4 } from 'uuid';
import { nanoid } from 'nanoid';
import { Room, Participant, CreateRoomDTO, ChatMessage } from '../models/types.js';

class RoomService {
  private rooms: Map<string, Room> = new Map();
  private socketToRoom: Map<string, string> = new Map();
  private socketToParticipant: Map<string, string> = new Map();

  // Generate a unique, URL-friendly room ID (like whereby)
  generateRoomId(): string {
    // Format: abc-def-ghi (3 groups of 3 chars)
    const part1 = nanoid(3).toLowerCase();
    const part2 = nanoid(3).toLowerCase();
    const part3 = nanoid(3).toLowerCase();
    return `${part1}-${part2}-${part3}`;
  }

  // Generate host token for admin actions
  generateHostToken(roomId: string): string {
    return `host_${roomId}_${uuidv4().slice(0, 8)}`;
  }

  createRoom(dto: CreateRoomDTO): Room {
    const roomId = this.generateRoomId();
    const hostToken = this.generateHostToken(roomId);

    const room: Room = {
      id: roomId,
      name: dto.name || 'Video Conference',
      hostToken,
      isPrivate: dto.isPrivate || false,
      isLocked: false,
      maxParticipants: dto.maxParticipants || 10,
      participants: new Map(),
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    this.rooms.set(roomId, room);
    return room;
  }

  getRoom(roomId: string): Room | undefined {
    return this.rooms.get(roomId);
  }

  getRoomByHostToken(hostToken: string): Room | undefined {
    for (const room of this.rooms.values()) {
      if (room.hostToken === hostToken) {
        return room;
      }
    }
    return undefined;
  }

  // Add participant to room
  addParticipant(roomId: string, socketId: string, name: string): Participant | null {
    const room = this.rooms.get(roomId);
    if (!room) return null;

    // Check if room is full
    if (room.participants.size >= room.maxParticipants) {
      return null;
    }

    // Check if room is locked
    if (room.isLocked) {
      return null;
    }

    // Create participant
    const participant: Participant = {
      id: uuidv4(),
      socketId,
      name,
      isHost: room.participants.size === 0,
      hasAudio: true,
      hasVideo: true,
      joinedAt: new Date(),
    };

    room.participants.set(participant.id, participant);
    room.updatedAt = new Date();

    // Track socket mappings
    this.socketToRoom.set(socketId, roomId);
    this.socketToParticipant.set(socketId, participant.id);

    return participant;
  }

  removeParticipant(socketId: string): { roomId: string; participantId: string } | null {
    const roomId = this.socketToRoom.get(socketId);
    const participantId = this.socketToParticipant.get(socketId);

    if (!roomId || !participantId) return null;

    const room = this.rooms.get(roomId);
    if (!room) return null;

    // Remove participant
    room.participants.delete(participantId);
    room.updatedAt = new Date();

    // Clean up mappings
    this.socketToRoom.delete(socketId);
    this.socketToParticipant.delete(socketId);

    // If room is empty, delete it after a delay (for reconnection)
    if (room.participants.size === 0) {
      setTimeout(() => {
        const currentRoom = this.rooms.get(roomId);
        if (currentRoom && currentRoom.participants.size === 0) {
          this.rooms.delete(roomId);
        }
      }, 60000); // Keep room alive for 1 minute for reconnection
    }

    return { roomId, participantId };
  }

  getParticipant(socketId: string): Participant | null {
    const participantId = this.socketToParticipant.get(socketId);
    if (!participantId) return null;

    for (const room of this.rooms.values()) {
      return room.participants.get(participantId) || null;
    }
    return null;
  }

  getRoomParticipants(roomId: string): Participant[] {
    const room = this.rooms.get(roomId);
    if (!room) return [];
    return Array.from(room.participants.values());
  }

  // Host actions
  kickParticipant(hostSocketId: string, targetSocketId: string): boolean {
    const host = this.getParticipant(hostSocketId);
    if (!host?.isHost) return false;

    const targetInfo = this.removeParticipant(targetSocketId);
    return targetInfo !== null;
  }

  lockRoom(hostSocketId: string): boolean {
    const host = this.getParticipant(hostSocketId);
    if (!host?.isHost) return false;

    const roomId = this.socketToRoom.get(hostSocketId);
    if (!roomId) return false;

    const room = this.rooms.get(roomId);
    if (!room) return false;

    room.isLocked = true;
    room.updatedAt = new Date();
    return true;
  }

  unlockRoom(hostSocketId: string): boolean {
    const host = this.getParticipant(hostSocketId);
    if (!host?.isHost) return false;

    const roomId = this.socketToRoom.get(hostSocketId);
    if (!roomId) return false;

    const room = this.rooms.get(roomId);
    if (!room) return false;

    room.isLocked = false;
    room.updatedAt = new Date();
    return true;
  }

  // Get all rooms (for debugging)
  getAllRooms(): Room[] {
    return Array.from(this.rooms.values());
  }

  // Get room statistics
  getStats(): { totalRooms: number; totalParticipants: number } {
    let totalParticipants = 0;
    for (const room of this.rooms.values()) {
      totalParticipants += room.participants.size;
    }
    return {
      totalRooms: this.rooms.size,
      totalParticipants,
    };
  }
}

export const roomService = new RoomService();