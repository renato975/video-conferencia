import { useState, useEffect, useCallback, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { VideoTile } from '@/components/video/VideoTile';
import { VideoGrid } from '@/components/video/VideoGrid';
import { ControlBar } from '@/components/controls/ControlBar';
import { ChatPanel } from '@/components/chat/ChatPanel';
import { WaitingRoom } from '@/components/waiting-room/WaitingRoom';
import { DeviceSelector } from '@/components/common/DeviceSelector';
import { useRoomStore } from '@/store/roomStore';
import { useSocket } from '@/hooks/useSocket';
import { useWebRTC } from '@/hooks/useWebRTC';
import { getUserMedia } from '@/hooks/useMediaDevices';

export default function RoomPage() {
  const { roomId } = useParams<{ roomId: string }>();
  const navigate = useNavigate();
  
  const [hasJoined, setHasJoined] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [isChatOpen, setIsChatOpen] = useState(false);
  
  const {
    room,
    setRoomId,
    setRoom,
    localStream,
    setLocalStream,
    participants,
    participantId,
    isConnected,
    isHost,
    mediaState,
    toggleAudio,
    toggleVideo,
    reset,
  } = useRoomStore();

  // WebRTC callbacks
  const handleOffer = useCallback((to: string, offer: RTCSessionDescriptionInit) => {
    webRTC.sendOffer(to, offer);
  }, []);

  const handleAnswer = useCallback((to: string, answer: RTCSessionDescriptionInit) => {
    webRTC.sendAnswer(to, answer);
  }, []);

  const handleIceCandidate = useCallback((to: string, candidate: RTCIceCandidate) => {
    webRTC.sendIceCandidate(to, candidate);
  }, []);

  // Initialize socket
  const {
    joinRoom,
    leaveRoom,
    sendChatMessage,
    sendHostAction,
    updateMediaState,
  } = useSocket({
    roomId: roomId || '',
    userName: 'User', // TODO: Get from input
    onOffer: handleOffer,
    onAnswer: handleAnswer,
    onIceCandidate: handleIceCandidate,
  });

  // Initialize WebRTC
  const webRTC = useWebRTC({
    localStream,
    onOffer: handleOffer,
    onAnswer: handleAnswer,
    onIceCandidate: handleIceCandidate,
  });

  // Set room ID on mount
  useEffect(() => {
    if (roomId) {
      setRoomId(roomId);
    }
    
    return () => {
      // Cleanup on unmount
      webRTC.cleanup();
      reset();
    };
  }, [roomId]);

  // Join room when user clicks join
  const handleJoin = useCallback(() => {
    setHasJoined(true);
    joinRoom();
  }, [joinRoom]);

  // Handle media state changes
  useEffect(() => {
    if (hasJoined && isConnected) {
      updateMediaState(mediaState.hasAudio, mediaState.hasVideo);
    }
  }, [mediaState.hasAudio, mediaState.hasVideo, hasJoined, isConnected, updateMediaState]);

  // Handle new participants - initiate WebRTC connections
  useEffect(() => {
    if (!localStream || !isConnected) return;

    const participantsArray = Array.from(participants.values());
    
    participantsArray.forEach((participant) => {
      if (participant.id !== participantId) {
        webRTC.connectToPeer(participant.id);
      }
    });
  }, [participants, participantId, localStream, isConnected, webRTC]);

  // Handle leave
  const handleLeave = useCallback(() => {
    leaveRoom();
    webRTC.cleanup();
    reset();
    navigate('/');
  }, [leaveRoom, webRTC, reset, navigate]);

  // If hasn't joined yet, show waiting room
  if (!hasJoined) {
    return (
      <WaitingRoom
        roomName={roomId || 'Meeting'}
        onJoin={handleJoin}
      />
    );
  }

  return (
    <div className='flex flex-col h-screen bg-dark-300'>
      {/* Main Content Area */}
      <div className='flex-1 flex overflow-hidden'>
        {/* Video Grid */}
        <div className={`flex-1 ${isChatOpen ? 'mr-80' : ''} transition-all duration-300`}>
          <VideoGrid />
        </div>

        {/* Chat Panel */}
        {isChatOpen && (
          <div className='w-80 fixed right-0 top-0 bottom-0 z-40'>
            <ChatPanel
              onClose={() => setIsChatOpen(false)}
              onSendMessage={sendChatMessage}
            />
          </div>
        )}
      </div>

      {/* Room Info Bar */}
      <div className='px-4 py-2 bg-dark-200 border-t border-dark-100 flex items-center justify-between'>
        <div className='flex items-center gap-4'>
          <span className='text-sm text-gray-400'>Room:</span>
          <span className='text-sm font-mono text-white'>{roomId}</span>
          {isHost && (
            <span className='px-2 py-0.5 rounded text-xs bg-primary-600 text-white'>
              Host
            </span>
          )}
        </div>
        <div className='flex items-center gap-2 text-sm text-gray-400'>
          <span>👥 {participants.size + 1}</span>
        </div>
      </div>

      {/* Control Bar */}
      <ControlBar
        onToggleChat={() => setIsChatOpen(!isChatOpen)}
        onToggleSettings={() => setShowSettings(true)}
        isChatOpen={isChatOpen}
        onLockRoom={() => sendHostAction('lock')}
        onUnlockRoom={() => sendHostAction('unlock')}
      />

      {/* Settings Modal */}
      <DeviceSelector
        isOpen={showSettings}
        onClose={() => setShowSettings(false)}
      />
    </div>
  );
}