import {
  createWorker,
  Worker,
  Router,
  WebRtcTransport,
  Transport,
  Producer,
  Consumer,
} from 'mediasoup/node';

interface Room {
  id: string;
  router: Router;
  transports: Map<string, WebRtcTransport>;
  producers: Map<string, Producer>;
  consumers: Map<string, Consumer>;
  participants: Set<string>;
}

class MediaServer {
  private worker: Worker | null = null;
  private rooms: Map<string, Room> = new Map();

  async run() {
    // Create a mediasoup worker
    this.worker = await createWorker({
      logLevel: 'warn',
      rtcMinPort: 30000,
      rtcMaxPort: 30100,
    });

    console.log('[MediaServer] Worker created, pid:', this.worker.pid);
  }

  async createRoom(roomId: string): Promise<Router> {
    if (this.rooms.has(roomId)) {
      return this.rooms.get(roomId)!.router;
    }

    if (!this.worker) {
      throw new Error('Worker not initialized');
    }

    const router = await this.worker.createRouter({
      mediaCodecs: [
        {
          kind: 'audio',
          mimeType: 'audio/opus',
          clockRate: 48000,
          channels: 2,
        },
        {
          kind: 'video',
          mimeType: 'video/VP8',
          clockRate: 90000,
          parameters: {
            'x-google-start-bitrate': 1000,
          },
        },
        {
          kind: 'video',
          mimeType: 'video/VP9',
          clockRate: 90000,
          parameters: {
            'x-google-start-bitrate': 1000,
          },
        },
      ],
    });

    const room: Room = {
      id: roomId,
      router,
      transports: new Map(),
      producers: new Map(),
      consumers: new Map(),
      participants: new Set(),
    };

    this.rooms.set(roomId, room);
    console.log('[MediaServer] Room created:', roomId);

    return router;
  }

  async createWebRtcTransport(
    roomId: string,
    participantId: string
  ): Promise<WebRtcTransport> {
    const room = this.rooms.get(roomId);
    if (!room) {
      throw new Error('Room not found');
    }

    const transport = await room.router.createWebRtcTransport({
      listenInfos: [
        {
          ip: '0.0.0.0',
          announcedAddress: process.env.PUBLIC_IP || 'localhost',
        },
      ],
      initialAvailableOutgoingBitrate: 1000000,
      minimumAvailableOutgoingBitrate: 600000,
      maxIncomingBitrate: 0,
      webRtcServer: undefined,
    });

    room.transports.set(participantId, transport);
    room.participants.add(participantId);

    console.log('[MediaServer] Transport created for:', participantId, 'in room:', roomId);

    return transport;
  }

  async produce(
    roomId: string,
    participantId: string,
    transportId: string,
    kind: 'audio' | 'video',
    rtpParameters: any
  ): Promise<Producer> {
    const room = this.rooms.get(roomId);
    if (!room) {
      throw new Error('Room not found');
    }

    const transport = room.transports.get(participantId);
    if (!transport || transport.id !== transportId) {
      throw new Error('Transport not found');
    }

    const producer = await transport.produce({
      kind,
      rtpParameters,
    });

    room.producers.set(participantId, producer);

    console.log('[MediaServer] Producer created for:', participantId, 'kind:', kind);

    return producer;
  }

  async consume(
    roomId: string,
    consumerPeerId: string,
    producerPeerId: string,
    transportId: string
  ): Promise<Consumer> {
    const room = this.rooms.get(roomId);
    if (!room) {
      throw new Error('Room not found');
    }

    const producer = room.producers.get(producerPeerId);
    if (!producer) {
      throw new Error('Producer not found');
    }

    const transport = room.transports.get(consumerPeerId);
    if (!transport || transport.id !== transportId) {
      throw new Error('Transport not found');
    }

    const consumer = await transport.consume({
      producerId: producer.id,
      rtpCapabilities: room.router.rtpCapabilities,
    });

    room.consumers.set(`${consumerPeerId}:${producerPeerId}`, consumer);

    console.log('[MediaServer] Consumer created:', consumerPeerId, 'consuming from:', producerPeerId);

    return consumer;
  }

  async handleWebSocketUpgrade(request: any, socket: any, head: any) {
    // TODO: Implement WebSocket handling for mediasoup signaling
    // This would integrate with the main backend's Socket.io
    socket.write('HTTP/1.1 101 Switching Protocols\r\n\r\n');
  }

  close() {
    if (this.worker) {
      this.worker.close();
      this.worker = null;
    }
    this.rooms.clear();
    console.log('[MediaServer] Closed');
  }
}

export const mediaServer = new MediaServer();