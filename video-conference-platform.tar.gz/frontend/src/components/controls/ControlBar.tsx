import { Mic, MicOff, Video, VideoOff, MonitorUp, PhoneOff, MessageSquare, Settings, Users, Lock, Unlock } from 'lucide-react';
import { useRoomStore } from '@/store/roomStore';
import { useState } from 'react';

interface ControlBarProps {
  onToggleChat?: () => void;
  onToggleSettings?: () => void;
  isChatOpen?: boolean;
  onLockRoom?: () => void;
  onUnlockRoom?: () => void;
  onKickParticipant?: (participantId: string) => void;
}

export function ControlBar({
  onToggleChat,
  onToggleSettings,
  isChatOpen = false,
}: ControlBarProps) {
  const { mediaState, toggleAudio, toggleVideo, toggleScreenShare, isHost, room } = useRoomStore();

  return (
    <div className={`
      flex items-center justify-center gap-2 p-4
      bg-dark-200/95 backdrop-blur-md
      border-t border-dark-100
    `}>
      {/* Mic Button */}
      <button
        onClick={toggleAudio}
        className={`
          p-3 rounded-full transition-all duration-200
          ${mediaState.hasAudio 
            ? 'bg-dark-100 hover:bg-dark-300 text-gray-200' 
            : 'bg-red-500 hover:bg-red-600 text-white'
          }
        `}
        title={mediaState.hasAudio ? 'Mute microphone' : 'Unmute microphone'}
      >
        {mediaState.hasAudio ? (
          <Mic className='w-6 h-6' />
        ) : (
          <MicOff className='w-6 h-6' />
        )}
      </button>

      {/* Camera Button */}
      <button
        onClick={toggleVideo}
        className={`
          p-3 rounded-full transition-all duration-200
          ${mediaState.hasVideo 
            ? 'bg-dark-100 hover:bg-dark-300 text-gray-200' 
            : 'bg-red-500 hover:bg-red-600 text-white'
          }
        `}
        title={mediaState.hasVideo ? 'Turn off camera' : 'Turn on camera'}
      >
        {mediaState.hasVideo ? (
          <Video className='w-6 h-6' />
        ) : (
          <VideoOff className='w-6 h-6' />
        )}
      </button>

      {/* Screen Share Button */}
      <button
        onClick={toggleScreenShare}
        className={`
          p-3 rounded-full transition-all duration-200
          ${mediaState.screenShare 
            ? 'bg-primary-600 hover:bg-primary-700 text-white' 
            : 'bg-dark-100 hover:bg-dark-300 text-gray-200'
          }
        `}
        title={mediaState.screenShare ? 'Stop sharing screen' : 'Share screen'}
      >
        <MonitorUp className='w-6 h-6' />
      </button>

      {/* Divider */}
      <div className='w-px h-8 bg-dark-100 mx-2' />

      {/* Chat Button */}
      <button
        onClick={onToggleChat}
        className={`
          p-3 rounded-full transition-all duration-200
          ${isChatOpen 
            ? 'bg-primary-600 hover:bg-primary-700 text-white' 
            : 'bg-dark-100 hover:bg-dark-300 text-gray-200'
          }
        `}
        title='Toggle chat'
      >
        <MessageSquare className='w-6 h-6' />
      </button>

      {/* Settings Button */}
      <button
        onClick={onToggleSettings}
        className='p-3 rounded-full bg-dark-100 hover:bg-dark-300 text-gray-200 transition-all duration-200'
        title='Settings'
      >
        <Settings className='w-6 h-6' />
      </button>

      {/* Divider */}
      <div className='w-px h-8 bg-dark-100 mx-2' />

      {/* Leave Button */}
      <button
        className='p-3 rounded-full bg-red-500 hover:bg-red-600 text-white transition-all duration-200'
        title='Leave meeting'
      >
        <PhoneOff className='w-6 h-6' />
      </button>
    </div>
  );
}

export default ControlBar;