import { useRef, useEffect } from 'react';
import { Mic, MicOff, Video, VideoOff, Crown } from 'lucide-react';

interface VideoTileProps {
  stream?: MediaStream | null;
  name: string;
  isLocal?: boolean;
  isHost?: boolean;
  hasAudio?: boolean;
  hasVideo?: boolean;
  isSpeaking?: boolean;
}

export function VideoTile({
  stream,
  name,
  isLocal = false,
  isHost = false,
  hasAudio = true,
  hasVideo = true,
  isSpeaking = false,
}: VideoTileProps) {
  const videoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    if (videoRef.current && stream) {
      videoRef.current.srcObject = stream;
    }
  }, [stream]);

  const initials = name
    .split(' ')
    .map((n) => n[0])
    .join('')
    .toUpperCase()
    .slice(0, 2);

  return (
    <div
      className={`
        relative rounded-xl overflow-hidden bg-dark-200
        aspect-video w-full
        ${isSpeaking ? 'ring-2 ring-primary-500 ring-offset-2 ring-offset-dark-300' : ''}
        ${isLocal ? 'border-2 border-primary-500' : 'border border-dark-100'}
      `}
    >
      {/* Video or Avatar */}
      {hasVideo && stream ? (
        <video
          ref={videoRef}
          autoPlay
          playsInline
          muted={isLocal}
          className={`w-full h-full object-cover ${isLocal ? 'transform scale-x-[-1]' : ''}`}
        />
      ) : (
        <div className={`w-full h-full flex items-center justify-center ${isLocal ? 'bg-primary-900' : 'bg-dark-100'}`}>
          <div className={`${isLocal ? 'bg-primary-600' : 'bg-dark-200'} rounded-full w-20 h-20 flex items-center justify-center`}>
            <span className={`text-2xl font-bold ${isLocal ? 'text-white' : 'text-gray-400'}`}>
              {initials}
            </span>
          </div>
        </div>
      )}

      {/* Name Badge */}
      <div className={`absolute bottom-2 left-2 flex items-center gap-2 px-3 py-1.5 rounded-lg backdrop-blur-md ${
        isLocal ? 'bg-primary-600/80' : 'bg-dark-100/80'
      }`}>
        {isHost && <Crown className={`w-4 h-4 ${isLocal ? 'text-yellow-300' : 'text-yellow-400'}`} />}
        <span className={`text-sm font-medium ${isLocal ? 'text-white' : 'text-gray-200'}`}>
          {name} {isLocal && '(You)'}
        </span>
      </div>

      {/* Status Icons */}
      <div className={`absolute top-2 right-2 flex items-center gap-1.5`}>
        {!hasAudio && (
          <div className={`p-1.5 rounded-full ${isLocal ? 'bg-red-500/80' : 'bg-red-600/80'} backdrop-blur-md`}>
            <MicOff className={`w-4 h-4 ${isLocal ? 'text-white' : 'text-white'}`} />
          </div>
        )}
        {!hasVideo && (
          <div className={`p-1.5 rounded-full ${isLocal ? 'bg-red-500/80' : 'bg-red-600/80'} backdrop-blur-md`}>
            <VideoOff className={`w-4 h-4 ${isLocal ? 'text-white' : 'text-white'}`} />
          </div>
        )}
      </div>

      {/* Speaking Indicator */}
      {isSpeaking && (
        <div className={`absolute bottom-2 right-2 flex items-center gap-1 px-2 py-1 rounded-full ${
          isLocal ? 'bg-green-500/80' : 'bg-green-600/80'
        } backdrop-blur-md`}>
          <div className={`w-2 h-2 rounded-full ${isLocal ? 'bg-green-300 animate-pulse' : 'bg-green-400 animate-pulse'}`} />
          <span className={`text-xs font-medium ${isLocal ? 'text-green-100' : 'text-green-100'}`}>
            Speaking
          </span>
        </div>
      )}
    </div>
  );
}

export default VideoTile;