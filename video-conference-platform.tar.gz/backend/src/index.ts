import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import { createServer } from 'http';
import { config } from './config/env.js';
import roomRoutes from './routes/roomRoutes.js';
import { initializeSocket } from './socket/index.js';
import { roomService } from './services/roomService.js';

const app = express();

// Middleware
app.use(helmet());
app.use(cors(config.cors));
app.use(express.json());

// Health check
app.get('/health', (req, res) => {
  res.json({
    status: 'healthy',
    uptime: process.uptime(),
    timestamp: new Date().toISOString(),
  });
});

// Stats endpoint (for monitoring)
app.get('/stats', (req, res) => {
  const stats = roomService.getStats();
  res.json({
    rooms: stats.totalRooms,
    participants: stats.totalParticipants,
    memory: process.memoryUsage(),
    uptime: process.uptime(),
  });
});

// API routes
app.use('/api', roomRoutes);

// Error handling
app.use((err: any, req: express.Request, res: express.Response, next: express.NextFunction) => {
  console.error('[Error]', err.stack);
  res.status(500).json({
    success: false,
    error: {
      message: 'Internal server error',
    },
  });
});

// 404 handler
app.use((req, res) => {
  res.status(404).json({
    success: false,
    error: {
      message: 'Not found',
    },
  });
});

// Create HTTP server and initialize Socket.io
const httpServer = createServer(app);
initializeSocket(httpServer);

// Start server
httpServer.listen(config.port, () => {
  console.log(`
╔════════════════════════════════════════════════════════════╗
║           VIDEO CONFERENCE BACKEND SERVER                  ║
╠════════════════════════════════════════════════════════════╣
║  🚀 Server running on http://localhost:${config.port}                ║
║  🔌 Socket.io enabled                                      ║
║  📊 Environment: ${config.nodeEnv.padEnd(42)}║
╚════════════════════════════════════════════════════════════╝

  Endpoints:
    POST   /api/rooms          - Create a room
    GET    /api/rooms/:id      - Get room info
    POST   /api/rooms/:id/join - Validate join
    GET    /health             - Health check
    GET    /stats              - Server stats
  `);
});

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('[Server] SIGTERM received, shutting down gracefully...');
  httpServer.close(() => {
    console.log('[Server] HTTP server closed');
    process.exit(0);
  });
});

process.on('SIGINT', () => {
  console.log('[Server] SIGINT received, shutting down gracefully...');
  httpServer.close(() => {
    console.log('[Server] HTTP server closed');
    process.exit(0);
  });
});