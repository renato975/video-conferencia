import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Copy, Check, Lock, Users } from 'lucide-react';
import apiService from '@/services/api';

export default function CreateRoomPage() {
  const navigate = useNavigate();
  
  const [roomName, setRoomName] = useState('');
  const [maxParticipants, setMaxParticipants] = useState(10);
  const [isPrivate, setIsPrivate] = useState(false);
  const [isCreating, setIsCreating] = useState(false);
  const [createdRoom, setCreatedRoom] = useState<{
    id: string;
    name: string;
    hostToken: string;
  } | null>(null);
  const [copied, setCopied] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleCreateRoom = async () => {
    setIsCreating(true);
    setError(null);

    try {
      const response = await apiService.createRoom(
        roomName || undefined,
        isPrivate,
        maxParticipants
      );

      if (response.success) {
        setCreatedRoom(response.data);
      } else {
        setError('Failed to create room');
      }
    } catch (err) {
      setError('Something went wrong. Please try again.');
    } finally {
      setIsCreating(false);
    }
  };

  const handleCopyLink = () => {
    if (createdRoom) {
      const link = `${window.location.origin}/room/${createdRoom.id}`;
      navigator.clipboard.writeText(link);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleJoinRoom = () => {
    if (createdRoom) {
      navigate(`/room/${createdRoom.id}`);
    }
  };

  // If room was created, show success view
  if (createdRoom) {
    return (
      <div className='min-h-screen flex flex-col items-center justify-center p-4'>
        <div className='w-full max-w-md space-y-6'>
          {/* Success Header */}
          <div className='text-center space-y-2'>
            <div className='inline-flex items-center justify-center w-16 h-16 rounded-full bg-green-500/20 mb-4'>
              <Check className='w-8 h-8 text-green-400' />
            </div>
            <h1 className='text-2xl font-bold text-white'>Room Created!</h1>
            <p className='text-gray-400'>Share this link with others to join</p>
          </div>

          {/* Room Link Card */}
          <div className='bg-dark-200 rounded-2xl border border-dark-100 p-4'>
            <div className='flex items-center gap-3'>
              <div className='flex-1 px-4 py-3 rounded-xl bg-dark-100 text-center'>
                <span className='text-lg font-mono text-white'>
                  {createdRoom.id}
                </span>
              </div>
              <button
                onClick={handleCopyLink}
                className={`
                  p-3 rounded-xl transition-colors
                  ${copied 
                    ? 'bg-green-600 text-white' 
                    : 'bg-dark-100 hover:bg-dark-300 text-gray-300'
                  }
                `}
              >
                {copied ? <Check className='w-5 h-5' /> : <Copy className='w-5 h-5' />}
              </button>
            </div>
            <p className='text-xs text-gray-500 mt-2 text-center'>
              {copied ? 'Copied!' : 'Click to copy room link'}
            </p>
          </div>

          {/* Room Info */}
          <div className='flex items-center justify-center gap-6 text-sm text-gray-400'>
            {createdRoom.name && (
              <div className='flex items-center gap-2'>
                <span>📝 {createdRoom.name}</span>
              </div>
            )}
            <div className='flex items-center gap-2'>
              <Users className='w-4 h-4' />
              <span>Up to {maxParticipants}</span>
            </div>
          </div>

          {/* Join Button */}
          <button
            onClick={handleJoinRoom}
            className='
              w-full py-4 px-4 rounded-xl
              bg-primary-600 hover:bg-primary-700
              text-white font-medium text-lg
              transition-colors
            '
          >
            Enter Room
          </button>

          {/* Create Another */}
          <button
            onClick={() => {
              setCreatedRoom(null);
              setRoomName('');
              setIsPrivate(false);
              setMaxParticipants(10);
            }}
            className='w-full py-3 text-gray-400 hover:text-white transition-colors text-sm'
          >
            Create another room
          </button>
        </div>
      </div>
    );
  }

  // Create room form
  return (
    <div className='min-h-screen flex flex-col'>
      {/* Header */}
      <div className='p-4'>
        <button
          onClick={() => navigate('/')}
          className='flex items-center gap-2 text-gray-400 hover:text-white transition-colors'
        >
          <ArrowLeft className='w-5 h-5' />
          Back
        </button>
      </div>

      <div className='flex-1 flex flex-col items-center justify-center p-4'>
        <div className='w-full max-w-md space-y-6'>
          {/* Title */}
          <div className='text-center'>
            <h1 className='text-2xl font-bold text-white mb-2'>Create a Room</h1>
            <p className='text-gray-400'>Customize your meeting settings</p>
          </div>

          {/* Form */}
          <div className='bg-dark-200 rounded-2xl border border-dark-100 p-6 space-y-5'>
            {/* Room Name */}
            <div>
              <label className='block text-sm text-gray-400 mb-2'>Room Name (optional)</label>
              <input
                type='text'
                value={roomName}
                onChange={(e) => setRoomName(e.target.value)}
                placeholder='Team Meeting'
                className='
                  w-full px-4 py-3 rounded-xl
                  bg-dark-100 text-white
                  border border-dark-300
                  focus:outline-none focus:border-primary-500
                  placeholder-gray-600
                '
              />
            </div>

            {/* Max Participants */}
            <div>
              <label className='block text-sm text-gray-400 mb-2'>Maximum Participants</label>
              <div className='flex items-center gap-4'>
                <input
                  type='range'
                  min='2'
                  max='50'
                  value={maxParticipants}
                  onChange={(e) => setMaxParticipants(parseInt(e.target.value))}
                  className='flex-1 h-2 bg-dark-100 rounded-lg appearance-none cursor-pointer accent-primary-500'
                />
                <span className='text-white font-medium w-8 text-center'>{maxParticipants}</span>
              </div>
            </div>

            {/* Private Toggle */}
            <div className='flex items-center justify-between'>
              <div className='flex items-center gap-3'>
                <Lock className={`w-5 h-5 ${isPrivate ? 'text-primary-400' : 'text-gray-500'}`} />
                <div>
                  <p className='text-white font-medium'>Private Room</p>
                  <p className='text-xs text-gray-500'>Host controls who enters</p>
                </div>
              </div>
              <button
                onClick={() => setIsPrivate(!isPrivate)}
                className={`
                  relative w-12 h-6 rounded-full transition-colors
                  ${isPrivate ? 'bg-primary-600' : 'bg-dark-100'}
                `}
              >
                <span
                  className={`
                    absolute top-1 w-4 h-4 rounded-full bg-white
                    transition-transform
                    ${isPrivate ? 'translate-x-7' : 'translate-x-1'}
                  `}
                />
              </button>
            </div>

            {error && (
              <p className='text-red-400 text-sm text-center'>{error}</p>
            )}

            {/* Create Button */}
            <button
              onClick={handleCreateRoom}
              disabled={isCreating}
              className='
                w-full py-3 px-4 rounded-xl
                bg-primary-600 hover:bg-primary-700
                disabled:bg-dark-300 disabled:cursor-not-allowed
                text-white font-medium
                transition-colors
              '
            >
              {isCreating ? (
                <div className='flex items-center justify-center gap-2'>
                  <div className='w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin' />
                  Creating...
                </div>
              ) : (
                'Create Room'
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}