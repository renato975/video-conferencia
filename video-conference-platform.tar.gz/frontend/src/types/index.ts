export interface Participant {
  id: string;
  socketId: string;
  name: string;
  isHost: boolean;
  hasAudio: boolean;
  hasVideo: boolean;
  joinedAt: Date;
  stream?: MediaStream;
}

export interface Room {
  id: string;
  name: string;
  url: string;
  hostToken: string;
  isPrivate: boolean;
  isLocked: boolean;
  maxParticipants: number;
  createdAt: Date;
}

export interface ChatMessage {
  id: string;
  senderId: string;
  senderName: string;
  text: string;
  timestamp: Date;
}

export interface CreateRoomResponse {
  id: string;
  name: string;
  url: string;
  hostToken: string;
}

export interface MediaState {
  hasAudio: boolean;
  hasVideo: boolean;
  screenShare: boolean;
}

export interface PeerConnection {
  peerId: string;
  connection: RTCPeerConnection;
  stream?: MediaStream;
}