import { Server, Socket } from 'socket.io';
import { roomService } from '../services/roomService.js';
import { ServerToClientEvents, ClientToServerEvents } from '../models/types.js';

type TypedServer = Server<ClientToServerEvents, ServerToClientEvents>;
type TypedSocket = Socket<ClientToServerEvents, ServerToClientEvents>;

export function setupSignaling(server: TypedServer) {
  // Handle new connections
  server.on('connection', (socket: TypedSocket) => {
    console.log(`[Socket] Client connected: ${socket.id}`);

    // Join a room
    socket.on('join-room', (data, callback) => {
      handleJoinRoom(socket, data, callback);
    });

    // Leave a room
    socket.on('leave-room', (data, callback) => {
      handleLeaveRoom(socket, data, callback);
    });

    // WebRTC signaling
    socket.on('offer', (data) => {
      handleOffer(socket, data);
    });

    socket.on('answer', (data) => {
      handleAnswer(socket, data);
    });

    socket.on('ice-candidate', (data) => {
      handleIceCandidate(socket, data);
    });

    // Chat messages
    socket.on('chat-message', (data) => {
      handleChatMessage(socket, data);
    });

    // Host actions
    socket.on('host-action', (data, callback) => {
      handleHostAction(socket, data, callback);
    });

    // Update media state (mute/unmute)
    socket.on('update-media-state', (data) => {
      handleUpdateMediaState(socket, data);
    });

    // Disconnect
    socket.on('disconnect', () => {
      handleDisconnect(socket);
    });
  });
}

function handleJoinRoom(socket: TypedSocket, data: { roomId: string; name: string }, callback: (response: any) => void) {
  try {
    const { roomId, name } = data;

    // Join the socket room
    socket.join(`room:${roomId}`);

    // Add participant to room
    const participant = roomService.addParticipant(roomId, socket.id, name);

    if (!participant) {
      callback({
        success: false,
        error: {
          message: 'Failed to join room. Room may be full or locked.',
        },
      });
      return;
    }

    // Get all current participants
    const participants = roomService.getRoomParticipants(roomId);

    // Notify others that someone joined
    socket.to(`room:${roomId}`).emit('participant-joined', participant);

    // Confirm join to the user
    callback({
      success: true,
      data: {
        roomId,
        participantId: participant.id,
        participants,
        isHost: participant.isHost,
      },
    });

    console.log(`[Room] ${name} joined room ${roomId}. Total participants: ${participants.length}`);
  } catch (error) {
    console.error('[Socket] Error joining room:', error);
    callback({
      success: false,
      error: {
        message: 'Failed to join room',
      },
    });
  }
}

function handleLeaveRoom(socket: TypedSocket, data: {}, callback: (response: any) => void) {
  try {
    const info = roomService.removeParticipant(socket.id);

    if (info) {
      socket.leave(`room:${info.roomId}`);
      
      // Notify others
      socket.to(`room:${info.roomId}`).emit('participant-left', {
        participantId: info.participantId,
      });

      console.log(`[Room] Participant left room ${info.roomId}`);
    }

    callback({ success: true });
  } catch (error) {
    console.error('[Socket] Error leaving room:', error);
    callback({ success: false, error: { message: 'Failed to leave room' } });
  }
}

// WebRTC Offer - initiator wants to start peer connection
function handleOffer(socket: TypedSocket, data: { to: string; offer: any }) {
  const { to, offer } = data;
  
  // Find the target socket
  const targetSocket = findSocketByParticipantId(to);
  
  if (targetSocket) {
    targetSocket.emit('offer', {
      from: socket.id,
      offer,
    });
  }
}

// WebRTC Answer - responder accepts the peer connection
function handleAnswer(socket: TypedSocket, data: { to: string; answer: any }) {
  const { to, answer } = data;
  
  const targetSocket = findSocketByParticipantId(to);
  
  if (targetSocket) {
    targetSocket.emit('answer', {
      from: socket.id,
      answer,
    });
  }
}

// ICE Candidate - network candidate for NAT traversal
function handleIceCandidate(socket: TypedSocket, data: { to: string; candidate: any }) {
  const { to, candidate } = data;
  
  const targetSocket = findSocketByParticipantId(to);
  
  if (targetSocket) {
    targetSocket.emit('ice-candidate', {
      from: socket.id,
      candidate,
    });
  }
}

function handleChatMessage(socket: TypedSocket, data: { text: string }) {
  const roomInfo = getRoomInfoBySocket(socket.id);
  if (!roomInfo) return;

  const participant = roomService.getParticipant(socket.id);
  if (!participant) return;

  const message = {
    id: `msg_${Date.now()}`,
    roomId: roomInfo.roomId,
    senderId: participant.id,
    senderName: participant.name,
    text: data.text,
    timestamp: new Date(),
  };

  // Broadcast to all in room including sender
  server.to(`room:${roomInfo.roomId}`).emit('chat-message', message);
}

function handleHostAction(socket: TypedSocket, data: { action: string; targetId?: string }, callback: (response: any) => void) {
  const { action, targetId } = data;

  switch (action) {
    case 'kick':
      if (!targetId) {
        callback({ success: false, error: { message: 'Target required' } });
        return;
      }
      const targetSocket = findSocketByParticipantId(targetId);
      if (targetSocket) {
        targetSocket.emit('kicked');
        targetSocket.disconnect(true);
      }
      callback({ success: true });
      break;

    case 'lock':
      const locked = roomService.lockRoom(socket.id);
      if (locked) {
        socket.to(`room:${getRoomInfoBySocket(socket.id)?.roomId}`).emit('room-locked');
      }
      callback({ success: locked });
      break;

    case 'unlock':
      const unlocked = roomService.unlockRoom(socket.id);
      if (unlocked) {
        socket.to(`room:${getRoomInfoBySocket(socket.id)?.roomId}`).emit('room-unlocked');
      }
      callback({ success: unlocked });
      break;

    default:
      callback({ success: false, error: { message: 'Unknown action' } });
  }
}

function handleUpdateMediaState(socket: TypedSocket, data: { hasAudio: boolean; hasVideo: boolean }) {
  const participant = roomService.getParticipant(socket.id);
  if (!participant) return;

  participant.hasAudio = data.hasAudio;
  participant.hasVideo = data.hasVideo;

  const roomInfo = getRoomInfoBySocket(socket.id);
  if (roomInfo) {
    socket.to(`room:${roomInfo.roomId}`).emit('participant-updated', participant);
  }
}

function handleDisconnect(socket: TypedSocket) {
  console.log(`[Socket] Client disconnected: ${socket.id}`);
  
  const info = roomService.removeParticipant(socket.id);
  
  if (info) {
    // Notify others
    const roomInfo = getRoomInfoBySocket(socket.id);
    if (roomInfo) {
      socket.to(`room:${info.roomId}`).emit('participant-left', {
        participantId: info.participantId,
      });
    }
  }
}

// Helper: Find socket ID by participant ID
let server: TypedServer;

function findSocketByParticipantId(participantId: string): TypedSocket | undefined {
  // This is a simplified version - in production you'd maintain a mapping
  // For now, we broadcast to room and let the client filter
  return undefined; // We'll use a different approach below
}

// Better approach: Use room-based signaling
export function setupRoomSignaling(server: TypedServer) {
  // Store server reference for use in handlers
}

// Use a global map for socket-to-participant tracking
const participantIdToSocketId = new Map<string, string>();

function getRoomInfoBySocket(socketId: string): { roomId: string } | null {
  // Track which rooms a socket is in
  // This is handled by Socket.io's rooms property
  return null;
}

// Helper to emit to specific participant
function emitToParticipant(participantId: string, event: string, data: any) {
  // In a real implementation, maintain a participantId -> socketId map
  // For simplicity, we'll iterate through connected sockets
  const sockets = server.sockets.sockets;
  for (const [socketId, socket] of sockets) {
    const roomInfo = roomService.getAllRooms().find(r => 
      Array.from(r.participants.values()).some(p => p.id === participantId)
    );
    if (roomInfo) {
      // Found the room, emit to that room
      server.to(`room:${roomInfo.id}`).emit(event, data);
      break;
    }
  }
}

// Export updated handlers that work with the room service
export function setupSignalingWithServer(serverInstance: TypedServer) {
  server = serverInstance;
  setupSignaling(serverInstance);
}