import { useCallback, useRef, useState } from 'react';
import SimplePeer, { Instance as PeerInstance } from 'simple-peer';
import { useRoomStore } from '@/store/roomStore';

interface Peer {
  peerId: string;
  connection: PeerInstance;
  stream?: MediaStream;
}

interface UseWebRTCOptions {
  localStream: MediaStream | null;
  onOffer?: (to: string, offer: RTCSessionDescriptionInit) => void;
  onAnswer?: (to: string, answer: RTCSessionDescriptionInit) => void;
  onIceCandidate?: (to: string, candidate: RTCIceCandidate) => void;
}

export function useWebRTC(options: UseWebRTCOptions) {
  const { localStream, onOffer, onAnswer, onIceCandidate } = options;
  
  const [peers, setPeers] = useState<Map<string, Peer>>(new Map());
  const peersRef = useRef<Map<string, Peer>>(new Map());
  const initiatorRef = useRef<Set<string>>(new Set());

  const { participants, participantId } = useRoomStore();

  // Create a peer connection with another participant
  const createPeer = useCallback(
    (targetPeerId: string, initiator: boolean) => {
      if (!localStream) {
        console.warn('[WebRTC] No local stream available');
        return null;
      }

      // Check if peer already exists
      if (peersRef.current.has(targetPeerId)) {
        console.log('[WebRTC] Peer already exists:', targetPeerId);
        return peersRef.current.get(targetPeerId)!;
      }

      console.log('[WebRTC] Creating peer:', targetPeerId, 'initiator:', initiator);

      const peer = new SimplePeer({
        initiator,
        stream: localStream,
        trickle: true, // Enable ICE trickling
        config: {
          iceServers: [
            { urls: 'stun:stun.l.google.com:19302' },
            { urls: 'stun:stun1.l.google.com:19302' },
            // Add TURN server for production
          ],
        },
      });

      peer.on('signal', (data) => {
        console.log('[WebRTC] Signal:', data.type);
        if (data.type === 'offer') {
          onOffer?.(targetPeerId, data);
        } else if (data.type === 'answer') {
          onAnswer?.(targetPeerId, data);
        } else if (data.candidate) {
          onIceCandidate?.(targetPeerId, data);
        }
      });

      peer.on('stream', (remoteStream) => {
        console.log('[WebRTC] Received stream from:', targetPeerId);
        // Update peers with stream
        const peerData = peersRef.current.get(targetPeerId);
        if (peerData) {
          peerData.stream = remoteStream;
          setPeers(new Map(peersRef.current));
        }
      });

      peer.on('connect', () => {
        console.log('[WebRTC] Peer connected:', targetPeerId);
      });

      peer.on('close', () => {
        console.log('[WebRTC] Peer closed:', targetPeerId);
        peersRef.current.delete(targetPeerId);
        initiatorRef.current.delete(targetPeerId);
        setPeers(new Map(peersRef.current));
      });

      peer.on('error', (err) => {
        console.error('[WebRTC] Peer error:', targetPeerId, err);
      });

      const peerData: Peer = { peerId: targetPeerId, connection: peer };
      peersRef.current.set(targetPeerId, peerData);
      setPeers(new Map(peersRef.current));

      if (initiator) {
        initiatorRef.current.add(targetPeerId);
      }

      return peer;
    },
    [localStream, onOffer, onAnswer, onIceCandidate]
  );

  // Handle incoming offer
  const handleOffer = useCallback(
    (fromPeerId: string, offer: RTCSessionDescriptionInit) => {
      // Check if we already have a connection with this peer
      const existingPeer = peersRef.current.get(fromPeerId);
      
      if (existingPeer) {
        existingPeer.connection.signal(offer);
        return;
      }

      // Create non-initiator peer
      createPeer(fromPeerId, false);
      
      // Wait a tick for the peer to be created, then signal
      setTimeout(() => {
        const peer = peersRef.current.get(fromPeerId);
        if (peer) {
          peer.connection.signal(offer);
        }
      }, 100);
    },
    [createPeer]
  );

  // Handle incoming answer
  const handleAnswer = useCallback(
    (fromPeerId: string, answer: RTCSessionDescriptionInit) => {
      const peer = peersRef.current.get(fromPeerId);
      if (peer) {
        peer.connection.signal(answer);
      }
    },
    []
  );

  // Handle incoming ICE candidate
  const handleIceCandidate = useCallback(
    (fromPeerId: string, candidate: RTCIceCandidate) => {
      const peer = peersRef.current.get(fromPeerId);
      if (peer) {
        peer.connection.signal({ candidate });
      }
    },
    []
  );

  // Initiate connection with a new participant
  const connectToPeer = useCallback(
    (targetPeerId: string) => {
      if (peersRef.current.has(targetPeerId)) {
        return;
      }
      createPeer(targetPeerId, true);
    },
    [createPeer]
  );

  // Remove peer connection
  const removePeer = useCallback((targetPeerId: string) => {
    const peer = peersRef.current.get(targetPeerId);
    if (peer) {
      peer.connection.destroy();
      peersRef.current.delete(targetPeerId);
      initiatorRef.current.delete(targetPeerId);
      setPeers(new Map(peersRef.current));
    }
  }, []);

  // Get peer stream
  const getPeerStream = useCallback((peerId: string): MediaStream | undefined => {
    return peersRef.current.get(peerId)?.stream;
  }, []);

  // Clean up all peers
  const cleanup = useCallback(() => {
    peersRef.current.forEach((peer) => {
      peer.connection.destroy();
    });
    peersRef.current.clear();
    initiatorRef.current.clear();
    setPeers(new Map());
  }, []);

  return {
    peers,
    createPeer,
    connectToPeer,
    handleOffer,
    handleAnswer,
    handleIceCandidate,
    removePeer,
    getPeerStream,
    cleanup,
  };
}