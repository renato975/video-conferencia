const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:3001';

interface CreateRoomResponse {
  success: boolean;
  data: {
    id: string;
    name: string;
    url: string;
    hostToken: string;
  };
}

interface GetRoomResponse {
  success: boolean;
  data: {
    id: string;
    name: string;
    isPrivate: boolean;
    isLocked: boolean;
    participantCount: number;
    maxParticipants: number;
  };
}

class ApiService {
  private baseUrl = API_URL;

  async createRoom(name?: string, isPrivate = false, maxParticipants = 10): Promise<CreateRoomResponse> {
    const response = await fetch(`${this.baseUrl}/api/rooms`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        name: name || `Sala ${Date.now()}`,
        isPrivate,
        maxParticipants,
      }),
    });

    return response.json();
  }

  async getRoom(roomId: string): Promise<GetRoomResponse> {
    const response = await fetch(`${this.baseUrl}/api/rooms/${roomId}`);
    return response.json();
  }

  async validateJoin(roomId: string, name: string): Promise<{ success: boolean; data?: any; error?: any }> {
    const response = await fetch(`${this.baseUrl}/api/rooms/${roomId}/join`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ name }),
    });

    return response.json();
  }
}

export const apiService = new ApiService();
export default apiService;