import dotenv from 'dotenv';

dotenv.config();

export const config = {
  port: parseInt(process.env.PORT || '3001', 10),
  nodeEnv: process.env.NODE_ENV || 'development',
  
  // Redis
  redis: {
    url: process.env.REDIS_URL || 'redis://localhost:6379',
  },
  
  // CORS
  cors: {
    origin: process.env.CORS_ORIGIN || 'http://localhost:5173',
    credentials: true,
  },
  
  // Media Server
  mediaServer: {
    url: process.env.MEDIA_SERVER_URL || 'ws://localhost:3002',
  },
  
  // Room settings
  room: {
    maxParticipants: parseInt(process.env.MAX_PARTICIPANTS || '20', 10),
    defaultMaxParticipants: parseInt(process.env.DEFAULT_MAX_PARTICIPANTS || '10', 10),
  },
  
  // JWT (for future auth)
  jwt: {
    secret: process.env.JWT_SECRET || 'your-super-secret-key-change-in-production',
    expiresIn: '24h',
  },
};