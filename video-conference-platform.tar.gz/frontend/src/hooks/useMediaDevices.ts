import { useState, useEffect, useCallback } from 'react';

interface MediaDevices {
  audioInputs: MediaDeviceInfo[];
  videoInputs: MediaDeviceInfo[];
  audioOutputs: MediaDeviceInfo[];
}

interface UseMediaDevicesReturn {
  devices: MediaDevices;
  selectedAudioInput: string | null;
  selectedVideoInput: string | null;
  selectedAudioOutput: string | null;
  setSelectedAudioInput: (deviceId: string) => void;
  setSelectedVideoInput: (deviceId: string) => void;
  setSelectedAudioOutput: (deviceId: string) => void;
  refreshDevices: () => Promise<void>;
  error: string | null;
}

export function useMediaDevices(): UseMediaDevicesReturn {
  const [devices, setDevices] = useState<MediaDevices>({
    audioInputs: [],
    videoInputs: [],
    audioOutputs: [],
  });
  
  const [selectedAudioInput, setSelectedAudioInput] = useState<string | null>(null);
  const [selectedVideoInput, setSelectedVideoInput] = useState<string | null>(null);
  const [selectedAudioOutput, setSelectedAudioOutput] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const refreshDevices = useCallback(async () => {
    try {
      // Request permissions first
      await navigator.mediaDevices.enumerateDevices();
      
      const deviceList = await navigator.mediaDevices.enumerateDevices();
      
      setDevices({
        audioInputs: deviceList.filter((d) => d.kind === 'audioinput'),
        videoInputs: deviceList.filter((d) => d.kind === 'videoinput'),
        audioOutputs: deviceList.filter((d) => d.kind === 'audiooutput'),
      });

      // Set defaults if not selected
      if (!selectedAudioInput && devices.audioInputs.length > 0) {
        setSelectedAudioInput(devices.audioInputs[0].deviceId);
      }
      if (!selectedVideoInput && devices.videoInputs.length > 0) {
        setSelectedVideoInput(devices.videoInputs[0].deviceId);
      }
    } catch (err) {
      setError('Failed to enumerate devices');
      console.error('[MediaDevices] Error:', err);
    }
  }, [selectedAudioInput, selectedVideoInput, devices.audioInputs.length, devices.videoInputs.length]);

  useEffect(() => {
    refreshDevices();

    // Listen for device changes
    navigator.mediaDevices.addEventListener('devicechange', refreshDevices);
    
    return () => {
      navigator.mediaDevices.removeEventListener('devicechange', refreshDevices);
    };
  }, [refreshDevices]);

  return {
    devices,
    selectedAudioInput,
    selectedVideoInput,
    selectedAudioOutput,
    setSelectedAudioInput,
    setSelectedVideoInput,
    setSelectedAudioOutput,
    refreshDevices,
    error,
  };
}

export async function getUserMedia(constraints?: MediaStreamConstraints): Promise<MediaStream> {
  const defaultConstraints: MediaStreamConstraints = {
    audio: {
      echoCancellation: true,
      noiseSuppression: true,
      autoGainControl: true,
    },
    video: {
      width: { ideal: 1280 },
      height: { ideal: 720 },
      frameRate: { ideal: 30 },
      facingMode: 'user',
    },
  };

  try {
    const stream = await navigator.mediaDevices.getUserMedia(
      constraints || defaultConstraints
    );
    return stream;
  } catch (error) {
    console.error('[getUserMedia] Error:', error);
    throw error;
  }
}

export async function getDisplayMedia(): Promise<MediaStream> {
  try {
    const stream = await navigator.mediaDevices.getDisplayMedia({
      video: {
        cursor: 'always',
      },
      audio: false,
    });
    return stream;
  } catch (error) {
    console.error('[getDisplayMedia] Error:', error);
    throw error;
  }
}