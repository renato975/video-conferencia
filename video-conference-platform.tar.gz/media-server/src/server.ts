import { createServer } from 'http';
import { mediaServer } from './mediaServer.js';

const port = parseInt(process.env.PORT || '3002', 10);

const httpServer = createServer();

async function main() {
  // Initialize mediasoup
  await mediaServer.run();

  // Handle WebSocket connections for media
  httpServer.on('upgrade', async (request, socket, head) => {
    if (request.url === '/mediasoup') {
      // Accept WebSocket connection
      // In a full implementation, you'd validate the token here
      await mediaServer.handleWebSocketUpgrade(request, socket, head);
    }
  });

  httpServer.listen(port, () => {
    console.log(`
╔════════════════════════════════════════════════════════════╗
║              MEDIASOUP MEDIA SERVER                        ║
╠════════════════════════════════════════════════════════════╣
║  🚀 Running on port ${port}                                  ║
║  🔄 WebRTC transports ready                                ║
║  📹 Media workers: ${process.env.MEDIASOUP_NUM_WORKERS || 'auto'}                              ║
╚════════════════════════════════════════════════════════════╝
    `);
  });
}

main().catch((err) => {
  console.error('[MediaServer] Failed to start:', err);
  process.exit(1);
});

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('[MediaServer] Shutting down...');
  mediaServer.close();
  process.exit(0);
});