import { useEffect, useCallback, useRef } from 'react';
import { Socket } from 'socket.io-client';
import socketService from '@/services/socket';
import { useRoomStore } from '@/store/roomStore';
import type { Participant, ChatMessage } from '@/types';

interface UseSocketOptions {
  roomId: string;
  userName: string;
  onOffer?: (from: string, offer: RTCSessionDescriptionInit) => void;
  onAnswer?: (from: string, answer: RTCSessionDescriptionInit) => void;
  onIceCandidate?: (from: string, candidate: RTCIceCandidate) => void;
}

export function useSocket(options: UseSocketOptions) {
  const { roomId, userName, onOffer, onAnswer, onIceCandidate } = options;
  
  const socketRef = useRef<Socket | null>(null);
  const callbacksRef = useRef({ onOffer, onAnswer, onIceCandidate });
  
  // Update callbacks ref when they change
  callbacksRef.current = { onOffer, onAnswer, onIceCandidate };

  const {
    setIsHost,
    setParticipantId,
    addParticipant,
    removeParticipant,
    setParticipants,
    setConnected,
    setConnecting,
    setError,
    addMessage,
  } = useRoomStore();

  const joinRoom = useCallback(() => {
    if (!socketRef.current) return;

    setConnecting(true);

    socketRef.current.emit(
      'join-room',
      { roomId, name: userName },
      (response: any) => {
        if (response.success) {
          const { participantId, participants, isHost } = response.data;
          setParticipantId(participantId);
          setIsHost(isHost);
          setParticipants(participants);
          setConnected(true);
          setConnecting(false);
        } else {
          setError(response.error?.message || 'Failed to join room');
          setConnecting(false);
        }
      }
    );
  }, [roomId, userName, setParticipantId, setIsHost, setParticipants, setConnected, setConnecting, setError]);

  const leaveRoom = useCallback(() => {
    if (!socketRef.current) return;

    socketRef.current.emit('leave-room', {}, () => {
      setConnected(false);
    });
  }, [setConnected]);

  const sendOffer = useCallback((to: string, offer: RTCSessionDescriptionInit) => {
    if (!socketRef.current) return;
    socketRef.current.emit('offer', { to, offer });
  }, []);

  const sendAnswer = useCallback((to: string, answer: RTCSessionDescriptionInit) => {
    if (!socketRef.current) return;
    socketRef.current.emit('answer', { to, answer });
  }, []);

  const sendIceCandidate = useCallback((to: string, candidate: RTCIceCandidate) => {
    if (!socketRef.current) return;
    socketRef.current.emit('ice-candidate', { to, candidate });
  }, []);

  const sendChatMessage = useCallback((text: string) => {
    if (!socketRef.current) return;
    socketRef.current.emit('chat-message', { text });
  }, []);

  const sendHostAction = useCallback((action: string, targetId?: string) => {
    if (!socketRef.current) return;
    socketRef.current.emit('host-action', { action, targetId });
  }, []);

  const updateMediaState = useCallback((hasAudio: boolean, hasVideo: boolean) => {
    if (!socketRef.current) return;
    socketRef.current.emit('update-media-state', { hasAudio, hasVideo });
  }, []);

  useEffect(() => {
    const socket = socketService.connect();
    socketRef.current = socket;

    // Room events
    socket.on('room-joined', (data) => {
      console.log('[Socket] Room joined:', data);
    });

    socket.on('participant-joined', (participant: Participant) => {
      console.log('[Socket] Participant joined:', participant);
      addParticipant(participant);
    });

    socket.on('participant-left', (data: { participantId: string }) => {
      console.log('[Socket] Participant left:', data.participantId);
      removeParticipant(data.participantId);
    });

    socket.on('participant-updated', (participant: Participant) => {
      console.log('[Socket] Participant updated:', participant);
      addParticipant(participant); // This will update existing
    });

    // WebRTC signaling
    socket.on('offer', (data: { from: string; offer: RTCSessionDescriptionInit }) => {
      console.log('[Socket] Received offer from:', data.from);
      callbacksRef.current.onOffer?.(data.from, data.offer);
    });

    socket.on('answer', (data: { from: string; answer: RTCSessionDescriptionInit }) => {
      console.log('[Socket] Received answer from:', data.from);
      callbacksRef.current.onAnswer?.(data.from, data.answer);
    });

    socket.on('ice-candidate', (data: { from: string; candidate: RTCIceCandidate }) => {
      console.log('[Socket] Received ICE candidate from:', data.from);
      callbacksRef.current.onIceCandidate?.(data.from, data.candidate);
    });

    // Chat
    socket.on('chat-message', (message: ChatMessage) => {
      console.log('[Socket] Chat message:', message);
      addMessage(message);
    });

    // Room state
    socket.on('room-locked', () => {
      console.log('[Socket] Room locked');
      useRoomStore.getState().setRoom({ ...useRoomStore.getState().room!, isLocked: true } as any);
    });

    socket.on('room-unlocked', () => {
      console.log('[Socket] Room unlocked');
      useRoomStore.getState().setRoom({ ...useRoomStore.getState().room!, isLocked: false } as any);
    });

    socket.on('kicked', () => {
      console.log('[Socket] You were kicked');
      setError('You were removed from the room');
      setConnected(false);
    });

    socket.on('error', (error: { message: string }) => {
      console.error('[Socket] Error:', error);
      setError(error.message);
    });

    return () => {
      socket.off('room-joined');
      socket.off('participant-joined');
      socket.off('participant-left');
      socket.off('participant-updated');
      socket.off('offer');
      socket.off('answer');
      socket.off('ice-candidate');
      socket.off('chat-message');
      socket.off('room-locked');
      socket.off('room-unlocked');
      socket.off('kicked');
      socket.off('error');
    };
  }, [addParticipant, removeParticipant, addMessage, setConnected, setError]);

  return {
    joinRoom,
    leaveRoom,
    sendOffer,
    sendAnswer,
    sendIceCandidate,
    sendChatMessage,
    sendHostAction,
    updateMediaState,
    socket: socketRef.current,
  };
}