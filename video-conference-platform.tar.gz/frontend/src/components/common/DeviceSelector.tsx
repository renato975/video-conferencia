import { useState } from 'react';
import { X } from 'lucide-react';
import { useMediaDevices } from '@/hooks/useMediaDevices';

interface DeviceSelectorProps {
  isOpen: boolean;
  onClose: () => void;
}

export function DeviceSelector({ isOpen, onClose }: DeviceSelectorProps) {
  const {
    devices,
    selectedAudioInput,
    selectedVideoInput,
    setSelectedAudioInput,
    setSelectedVideoInput,
  } = useMediaDevices();

  const [activeTab, setActiveTab] = useState<'audio' | 'video'>('audio');

  if (!isOpen) return null;

  return (
    <div className='fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm'>
      <div className='w-full max-w-md bg-dark-200 rounded-xl border border-dark-100 shadow-2xl'>
        {/* Header */}
        <div className='flex items-center justify-between p-4 border-b border-dark-100'>
          <h2 className='text-lg font-semibold text-white'>Settings</h2>
          <button
            onClick={onClose}
            className='p-2 rounded-lg hover:bg-dark-100 text-gray-400 hover:text-white transition-colors'
          >
            <X className='w-5 h-5' />
          </button>
        </div>

        {/* Tabs */}
        <div className='flex border-b border-dark-100'>
          <button
            onClick={() => setActiveTab('audio')}
            className={`
              flex-1 py-3 text-sm font-medium transition-colors
              ${activeTab === 'audio' 
                ? 'text-primary-400 border-b-2 border-primary-400' 
                : 'text-gray-400 hover:text-white'
              }
            `}
          >
            Audio
          </button>
          <button
            onClick={() => setActiveTab('video')}
            className={`
              flex-1 py-3 text-sm font-medium transition-colors
              ${activeTab === 'video' 
                ? 'text-primary-400 border-b-2 border-primary-400' 
                : 'text-gray-400 hover:text-white'
              }
            `}
          >
            Video
          </button>
        </div>

        {/* Content */}
        <div className='p-4'>
          {activeTab === 'audio' && (
            <div className='space-y-4'>
              <div>
                <label className='block text-sm text-gray-400 mb-2'>Microphone</label>
                <select
                  value={selectedAudioInput || ''}
                  onChange={(e) => setSelectedAudioInput(e.target.value)}
                  className='w-full px-4 py-2 rounded-lg bg-dark-100 text-white border border-dark-300 focus:outline-none focus:border-primary-500'
                >
                  {devices.audioInputs.map((device) => (
                    <option key={device.deviceId} value={device.deviceId}>
                      {device.label || `Microphone ${device.deviceId.slice(0, 8)}`}
                    </option>
                  ))}
                </select>
              </div>

              <div className='space-y-2'>
                <label className='block text-sm text-gray-400 mb-2'>Speaker</label>
                <select
                  className='w-full px-4 py-2 rounded-lg bg-dark-100 text-white border border-dark-300 focus:outline-none focus:border-primary-500'
                >
                  {devices.audioOutputs.map((device) => (
                    <option key={device.deviceId} value={device.deviceId}>
                      {device.label || `Speaker ${device.deviceId.slice(0, 8)}`}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          )}

          {activeTab === 'video' && (
            <div className='space-y-4'>
              <div>
                <label className='block text-sm text-gray-400 mb-2'>Camera</label>
                <select
                  value={selectedVideoInput || ''}
                  onChange={(e) => setSelectedVideoInput(e.target.value)}
                  className='w-full px-4 py-2 rounded-lg bg-dark-100 text-white border border-dark-300 focus:outline-none focus:border-primary-500'
                >
                  {devices.videoInputs.map((device) => (
                    <option key={device.deviceId} value={device.deviceId}>
                      {device.label || `Camera ${device.deviceId.slice(0, 8)}`}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className='p-4 border-t border-dark-100'>
          <button
            onClick={onClose}
            className='w-full py-2 px-4 rounded-lg bg-primary-600 hover:bg-primary-700 text-white font-medium transition-colors'
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
}

export default DeviceSelector;