import { useState, useEffect } from 'react';
import { Video, Mic, Settings } from 'lucide-react';
import { getUserMedia } from '@/hooks/useMediaDevices';
import { useRoomStore } from '@/store/roomStore';
import { useMediaDevices } from '@/hooks/useMediaDevices';

interface WaitingRoomProps {
  roomName: string;
  onJoin: () => void;
}

export function WaitingRoom({ roomName, onJoin }: WaitingRoomProps) {
  const { setLocalStream, error, setError } = useRoomStore();
  const { devices, selectedAudioInput, selectedVideoInput, setSelectedAudioInput, setSelectedVideoInput } = useMediaDevices();
  
  const [isLoading, setIsLoading] = useState(true);
  const [previewStream, setPreviewStream] = useState<MediaStream | null>(null);

  useEffect(() => {
    startPreview();

    return () => {
      stopPreview();
    };
  }, []);

  const startPreview = async () => {
    try {
      setIsLoading(true);
      const stream = await getUserMedia();
      setPreviewStream(stream);
      setLocalStream(stream);
      setError(null);
    } catch (err: any) {
      console.error('[WaitingRoom] Error starting preview:', err);
      setError(err.message || 'Failed to access camera/microphone');
    } finally {
      setIsLoading(false);
    }
  };

  const stopPreview = () => {
    if (previewStream) {
      previewStream.getTracks().forEach(track => track.stop());
      setPreviewStream(null);
    }
  };

  const videoRef = React.useRef<HTMLVideoElement>(null);

  useEffect(() => {
    if (videoRef.current && previewStream) {
      videoRef.current.srcObject = previewStream;
    }
  }, [previewStream]);

  return (
    <div className='flex flex-col items-center justify-center min-h-screen bg-dark-300 p-4'>
      <div className='w-full max-w-md space-y-6'>
        {/* Header */}
        <div className='text-center'>
          <h1 className='text-2xl font-bold text-white mb-2'>Joining {roomName}</h1>
          <p className='text-gray-400'>Check your camera and microphone before joining</p>
        </div>

        {/* Preview */}
        <div className='relative aspect-video rounded-xl overflow-hidden bg-dark-200 border border-dark-100'>
          {isLoading ? (
            <div className='flex items-center justify-center h-full'>
              <div className='animate-spin w-8 h-8 border-2 border-primary-500 border-t-transparent rounded-full' />
            </div>
          ) : previewStream ? (
            <video
              ref={videoRef}
              autoPlay
              playsInline
              muted
              className='w-full h-full object-cover transform scale-x-[-1]'
            />
          ) : (
            <div className='flex flex-col items-center justify-center h-full text-gray-500'>
              <Video className='w-12 h-12 mb-2' />
              <p>Camera preview unavailable</p>
            </div>
          )}

          {/* Overlay with controls hint */}
          <div className='absolute bottom-4 left-4 right-4 flex items-center justify-between'>
            <div className='flex items-center gap-2 px-3 py-1.5 rounded-lg bg-dark-100/80 backdrop-blur-sm'>
              <Mic className='w-4 h-4 text-gray-300' />
              <span className='text-sm text-gray-300'>Microphone ready</span>
            </div>
          </div>
        </div>

        {/* Error */}
        {error && (
          <div className='p-4 rounded-lg bg-red-500/10 border border-red-500/20 text-red-400 text-sm'>
            <p className='font-medium mb-1'>Permission Error</p>
            <p>{error}</p>
            <button
              onClick={startPreview}
              className='mt-2 text-sm underline hover:text-red-300'
            >
              Try again
            </button>
          </div>
        )}

        {/* Device Selector */}
        <div className='space-y-3'>
          <div className='flex items-center gap-2 text-gray-400'>
            <Settings className='w-4 h-4' />
            <span className='text-sm'>Audio & Video Settings</span>
          </div>

          <select
            value={selectedVideoInput || ''}
            onChange={(e) => setSelectedVideoInput(e.target.value)}
            className='w-full px-4 py-2 rounded-lg bg-dark-100 text-white border border-dark-300 focus:outline-none focus:border-primary-500'
          >
            {devices.videoInputs.map((device) => (
              <option key={device.deviceId} value={device.deviceId}>
                {device.label || `Camera ${device.deviceId.slice(0, 8)}`}
              </option>
            ))}
          </select>

          <select
            value={selectedAudioInput || ''}
            onChange={(e) => setSelectedAudioInput(e.target.value)}
            className='w-full px-4 py-2 rounded-lg bg-dark-100 text-white border border-dark-300 focus:outline-none focus:border-primary-500'
          >
            {devices.audioInputs.map((device) => (
              <option key={device.deviceId} value={device.deviceId}>
                {device.label || `Microphone ${device.deviceId.slice(0, 8)}`}
              </option>
            ))}
          </select>
        </div>

        {/* Join Button */}
        <button
          onClick={onJoin}
          disabled={isLoading || !previewStream}
          className='
            w-full py-3 px-4 rounded-lg
            bg-primary-600 hover:bg-primary-700
            disabled:bg-dark-100 disabled:text-gray-500
            text-white font-medium
            transition-colors
          '
        >
          {isLoading ? 'Preparing...' : 'Join Meeting'}
        </button>
      </div>
    </div>
  );
}

// Need React import for useRef
import React from 'react';

export default WaitingRoom;