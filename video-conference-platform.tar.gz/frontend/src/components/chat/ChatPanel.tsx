import { useState, useRef, useEffect } from 'react';
import { X, Send } from 'lucide-react';
import { useRoomStore } from '@/store/roomStore';
import type { ChatMessage } from '@/types';

interface ChatPanelProps {
  onClose: () => void;
  onSendMessage: (text: string) => void;
}

export function ChatPanel({ onClose, onSendMessage }: ChatPanelProps) {
  const { messages } = useRoomStore();
  const [inputValue, setInputValue] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Auto-scroll to bottom when new messages arrive
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (inputValue.trim()) {
      onSendMessage(inputValue.trim());
      setInputValue('');
    }
  };

  const formatTime = (date: Date) => {
    return new Date(date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  return (
    <div className='flex flex-col h-full bg-dark-200 border-l border-dark-100'>
      {/* Header */}
      <div className='flex items-center justify-between p-4 border-b border-dark-100'>
        <h2 className='text-lg font-semibold text-white'>Chat</h2>
        <button
          onClick={onClose}
          className='p-2 rounded-lg hover:bg-dark-100 text-gray-400 hover:text-white transition-colors'
        >
          <X className='w-5 h-5' />
        </button>
      </div>

      {/* Messages */}
      <div className='flex-1 overflow-y-auto p-4 space-y-4'>
        {messages.length === 0 ? (
          <div className='text-center text-gray-500 py-8'>
            <p>No messages yet</p>
            <p className='text-sm mt-2'>Start the conversation!</p>
          </div>
        ) : (
          messages.map((message) => (
            <MessageBubble key={message.id} message={message} />
          ))
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Input */}
      <form onSubmit={handleSubmit} className='p-4 border-t border-dark-100'>
        <div className='flex items-center gap-2'>
          <input
            type='text'
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            placeholder='Type a message...'
            className='
              flex-1 px-4 py-2 rounded-lg
              bg-dark-100 text-white
              border border-dark-300
              focus:outline-none focus:border-primary-500
              placeholder-gray-500
            '
            maxLength={500}
          />
          <button
            type='submit'
            disabled={!inputValue.trim()}
            className='
              p-2 rounded-lg
              bg-primary-600 hover:bg-primary-700
              disabled:bg-dark-300 disabled:cursor-not-allowed
              text-white transition-colors
            '
          >
            <Send className='w-5 h-5' />
          </button>
        </div>
      </form>
    </div>
  );
}

interface MessageBubbleProps {
  message: ChatMessage;
}

function MessageBubble({ message }: MessageBubbleProps) {
  const formatTime = (date: Date) => {
    return new Date(date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  return (
    <div className='flex flex-col'>
      <div className='flex items-center gap-2 mb-1'>
        <span className='text-sm font-medium text-primary-400'>{message.senderName}</span>
        <span className='text-xs text-gray-500'>{formatTime(message.timestamp)}</span>
      </div>
      <div className='px-3 py-2 rounded-lg bg-dark-100 text-gray-200 max-w-[85%]'>
        <p className='text-sm break-words'>{message.text}</p>
      </div>
    </div>
  );
}

export default ChatPanel;